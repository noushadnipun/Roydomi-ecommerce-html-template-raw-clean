<?php include 'header.php'; ?>


<?php 
	//Slider
	include 'inc/homepage/slider.php'; 
	//Tile Category Block
	include 'inc/homepage/tile-cat-block.php'; 
	//Promo Area
	include 'inc/homepage/promo-area.php'; 
	//Latest Product
	include 'inc/homepage/latest-product.php'; 
	//Grid Banner
	include 'inc/homepage/grid-banner.php'; 
	//Tab
	include 'inc/homepage/tab.php';
	//Brand
	include 'inc/homepage/brand.php';

	?>



<?php include 'footer.php'; ?>