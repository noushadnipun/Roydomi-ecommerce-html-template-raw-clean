<div class="container-fluid mt-2">
    <div class="row container-fluid">
        <div class="col-lg-5">
           <img src="http://placehold.it/760x409" alt="" class="img-responsive center-block mb-2">
        </div>
        <div class="col-lg-7">
        	<div class="row">
	            <div class="col-md-6 col-6">
	              <img src="http://placehold.it/555x213" alt="" class="img-responsive mb-2">
	            </div>
	            <div class="col-md-6 col-6">
	              <img src="http://placehold.it/555x213" alt="" class="img-responsive mb-2">
	            </div>
	            <div class="col-md-6 col-6">
	              <img src="http://placehold.it/555x213" alt="" class="img-responsive mb-2">
	            </div>
	            <div class="col-md-6 col-6">
	              <img src="http://placehold.it/555x213" alt="" class="img-responsive mb-2">
	            </div>
            </div>
        </div>
    </div>
</div>