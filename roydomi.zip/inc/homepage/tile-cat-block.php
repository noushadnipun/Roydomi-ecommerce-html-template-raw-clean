<div class="container-fluid container-scroll mt-1">
	<div class="row container-fluid">
		<?php for ($x = 1; $x <= 8; $x++) { ?>
		<div class="res-scroll xtile-cat col-lg-3 pt-2 col-md-6">
	        <div class="single-product-category">
	            <span class="product-category-left">
	                <a href="#">
	                    <img src="assets/images/shop-by-category-living-room.jpg">
	                </a>
	            </span>
	            <span class="product-category-right">
	                 <h4>
	                    <a href="#">Bedroom </a>
	                </h4>
	                 <span class="view-details">
	                    <a href="#">View Details</a>
	                </span>
	           </span>
	       </div>
	    </div>
		<?php } ?>
	</div>
</div>
