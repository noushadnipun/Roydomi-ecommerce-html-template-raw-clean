<div class="container-fluid">
    <div class="promo-banner-section">
        <div class="buzz-container buzz-clearfix">
            <div class="row container-fluid">
            <?php for ($x = 1; $x <= 3; $x++) { ?>
                <div class="col-12 col-lg-4 mb-1">
                    <a href="#" class="promo-banner-img">
                        <div class="promo-banner-img-inner">
                            <div class="promo-bg-image-inner" style="background-image:url(assets/images/t-shirt.jpg)">
                                <img src="assets/images/t-shirt.jpg" alt="">
                            </div>
                            <div class="promo-img-info">
                                <div class="promo-img-info-inner">
                                    <h3>Fashion Design</h3>
                                    <!-- <p>New Year Offer, Get 10 % discount </p> -->
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php } ?>

            </div>
        </div>
    </div>
</div>