<div class="container-fluid mt-2">
   <div class="row container-fluid">
      <div class="col-12">
         <div class="wrapper-fluid">
            <div class="wrapper-fluid-title">
               <span class="h3">Top Brand's</span>
            </div>
            <!-- Brand Content-->
            <div class="row wrapper-fluid-padding" style="visibility: visible; animation-name: fadeInUp;">
               <?php for($x = 1; $x <=  6; $x++) { ?>
               <div class="col-lg-2 col-md-4 col-4">
                   <div class="brand-logo mw-100 mh-100"> 
                     <a href="#"><img src="assets/images/product/bata.png" class="img-fluid" alt=""> </a>
                  </div>
               </div>
               <?php } ?>
            </div><!-- End Bran Content -->
         </div>
      </div>
   </div>
</div>