<?php include 'header.php';?>

<div class="container mt-2">
    <div class="wrapper-fluid">
        <div class="wrapper-fluid-title">
            <span class="h3"> Sample Page </span>
        </div>
        <div class="wrapper-fluid-padding">
            <div class="row mb-3">
                <div class="col-md-12 mb-4">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vitae nunc sed velit dignissim. Tempor id eu nisl nunc mi. Sed vulputate odio ut enim. Eget sit amet tellus cras adipiscing enim eu turpis egestas. Nibh cras pulvinar mattis nunc sed. Mattis nunc sed blandit libero volutpat sed cras ornare. Pharetra pharetra massa massa ultricies mi quis hendrerit dolor magna. Scelerisque fermentum dui faucibus in. Arcu cursus vitae congue mauris. Massa id neque aliquam vestibulum morbi blandit cursus. Tortor at auctor urna nunc id cursus metus aliquam. Sollicitudin tempor id eu nisl nunc mi.</p>

                    

                    <p>Dictumst quisque sagittis purus sit amet volutpat consequat mauris nunc. Purus sit amet luctus venenatis lectus magna fringilla. Aliquam id diam maecenas ultricies mi eget. Viverra nibh cras pulvinar mattis. Aliquet enim tortor at auctor. Magnis dis parturient montes nascetur ridiculus. Maecenas sed enim ut sem viverra. Felis eget nunc lobortis mattis aliquam faucibus purus in massa. Vitae et leo duis ut. Nisi est sit amet facilisis. Convallis a cras semper auctor. Ullamcorper velit sed ullamcorper morbi tincidunt ornare massa eget egestas. Tincidunt tortor aliquam nulla facilisi cras fermentum odio eu feugiat. Sem fringilla ut morbi tincidunt augue interdum. Viverra mauris in aliquam sem fringilla ut morbi tincidunt augue.</p>

                    

                    <p>Vitae ultricies leo integer malesuada nunc vel risus. Sed elementum tempus egestas sed sed risus pretium. Phasellus egestas tellus rutrum tellus pellentesque eu tincidunt tortor. Scelerisque fermentum dui faucibus in ornare. Nisl vel pretium lectus quam id leo in vitae turpis. Augue mauris augue neque gravida in fermentum. Mauris in aliquam sem fringilla. Dictum at tempor commodo ullamcorper a lacus. Aenean et tortor at risus viverra adipiscing at. Mollis aliquam ut porttitor leo a diam sollicitudin tempor. Ut pharetra sit amet aliquam id diam maecenas ultricies mi.</p>

                    

                    <p>Vitae ultricies leo integer malesuada nunc vel risus. Sed elementum tempus egestas sed sed risus pretium. Phasellus egestas tellus rutrum tellus pellentesque eu tincidunt tortor. Scelerisque fermentum dui faucibus in ornare. Nisl vel pretium lectus quam id leo in vitae turpis. Augue mauris augue neque gravida in fermentum. Mauris in aliquam sem fringilla. Dictum at tempor commodo ullamcorper a lacus. Aenean et tortor at risus viverra adipiscing at. Mollis aliquam ut porttitor leo a diam sollicitudin tempor. Ut pharetra sit amet aliquam id diam maecenas ultricies mi.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php' ;?>